-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 09, 2019 at 04:41 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `ISBN` bigint(50) NOT NULL,
  `TITLE` varchar(50) NOT NULL,
  `AUTHOR` varchar(50) NOT NULL,
  `GENRE` varchar(50) NOT NULL,
  `DESCRIPTION` varchar(500) NOT NULL,
  `PUBLISHER` varchar(50) NOT NULL,
  `DATE_PUBLISHED` varchar(50) NOT NULL,
  `STOCKS` int(5) NOT NULL,
  `PRICE` int(7) NOT NULL,
  PRIMARY KEY (`ISBN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`ISBN`, `TITLE`, `AUTHOR`, `GENRE`, `DESCRIPTION`, `PUBLISHER`, `DATE_PUBLISHED`, `STOCKS`, `PRICE`) VALUES
(9781524741716, 'Warcross', 'Marie Lu', 'Science fiction', 'Warcross isn''t just a game -it''s a way of life.', 'Putnam', '9-12-2017', 30, 579),
(9781524701086, 'Holding up the Universe', 'Jennifer Niven', 'Romance', 'Poignant and exhilarating love story.', 'Knopf', '4-4-2016', 20, 549),
(9781442426719, 'To All the Boys I''ve Loved Before', 'Jenny Han', 'Romance', 'Lara Jean and her love letters.', 'Simon & Schuster', '4-15-2014', 68, 395),
(9780142422076, 'Legend', 'Marie Lu', 'Dystopian', 'First Installment for the Legend series.', 'Speak', '11-29-2011', 50, 575),
(9780142415436, 'If I Stay', 'Gayle Forman', 'Young Adult', 'Aftermath of a catstrophic car accident.', 'Speak', '4-2-2009', 13, 399),
(9780142427552, 'Prodigy', 'Marie Lu', 'Dystopian', 'Second Installement for the Legend series.', 'Speak', '1-29-2013', 23, 499),
(9781410462022, 'Champion', 'Marie Lu', 'Dystopian', 'Third Installment for the Legend series.', 'Speak', '11-5-2013', 34, 499),
(9781250221704, 'Rebel', 'Marie Lu', 'Dystopian', 'Fourth Installment for the Legend series.', 'Speak', '9-1-2019', 67, 575),
(9781250317421, 'Archenemies', 'Marissa Meyer', 'Science Fiction', 'Second Installment of Renegades Trilogy.', 'Feiwel and Friends', '11-6-2018', 45, 679),
(9780786891177, 'For One More Day', 'Mitch Albom', 'Fiction', '"It''s such a shame to waste time. We always think we have so much of it."', 'Hachette Books', '8-26-2006', 13, 370),
(9781401398033, 'The Five People You Meet in Heaven', 'Mitch Albom', 'Fiction', '"Each affects the other and the other affects the next."', 'Hachette Books', '9-23-2003', 21, 395),
(9780062380869, 'This Savage Song', 'Victoria Schwab', 'Fantasy', 'There is no such thing as safe in a city full of monsters.', 'Greenwillow', '6-7-2016', 11, 379),
(9780062380890, 'Our Dark Duet', 'Victoria Schwab', 'Fantasy', 'Final Installment for the Monsters of Verity series.', 'Greenwillow', '6-13-2017', 22, 459);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `CUSTOMER_ID` int(3) NOT NULL,
  `EMPLOYEE_ID` int(3) NOT NULL,
  `ISBN` int(20) NOT NULL,
  `PRICE` int(5) NOT NULL,
  `QUANTITY` int(5) NOT NULL,
  `TOTAL_PRICE` int(5) NOT NULL,
  `PAYMENT` int(10) NOT NULL,
  `CHANGE_` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `EMP_ID` int(5) NOT NULL,
  `FIRST_NAME` varchar(50) NOT NULL,
  `LAST_NAME` varchar(50) NOT NULL,
  `MIDDLE_INITIAL` varchar(50) NOT NULL,
  `BIRTHDAY` varchar(50) NOT NULL,
  `AGE` int(3) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `POSITION` varchar(50) NOT NULL,
  PRIMARY KEY (`EMP_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EMP_ID`, `FIRST_NAME`, `LAST_NAME`, `MIDDLE_INITIAL`, `BIRTHDAY`, `AGE`, `ADDRESS`, `POSITION`) VALUES
(201810246, 'Maria Stephanie', 'Blanco', 'D', '12-22-1999', 19, 'Imus Cavite', 'Architect'),
(201412522, 'Mary Claudine', 'Sta. Maria', 'M', '2-16-', 24, 'Las Pinas', 'Engineer'),
(201810309, 'Jhoebe Kates', 'Uy', 'A', '5-30-2000', 19, 'Dasmarinas Cavite', 'Book Specialist'),
(201810088, 'Queen Marlen', 'Camiloza', 'S', '9-13-1997', 22, 'Bacoor Cavite', 'Guard'),
(201512380, 'Rose Ann', 'Santos', 'P', '1-7', 21, 'Dasmarinas Cavite', 'Manager');
